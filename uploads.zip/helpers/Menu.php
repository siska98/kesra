<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbarsideleft = array(
		array(
			'path' => 'home', 
			'label' => 'Home', 
			'icon' => '<i class="fa fa-home fa-2x"></i>'
		),
		
		array(
			'path' => 'bintal', 
			'label' => 'Bintal', 
			'icon' => '<i class="fa fa-list fa-2x"></i>'
		),
		
		array(
			'path' => 'kesmas', 
			'label' => 'Kesmas', 
			'icon' => '<i class="fa fa-list fa-2x"></i>'
		),
		
		array(
			'path' => 'sosial', 
			'label' => 'Kesos', 
			'icon' => '<i class="fa fa-list fa-2x"></i>'
		),
		
		array(
			'path' => 'pengguna', 
			'label' => 'Pengguna', 
			'icon' => '<i class="fa fa-user fa-2x"></i>'
		)
	);
		
	
	
}